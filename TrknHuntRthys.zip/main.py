from core.banner import bannerr, banner
from core.scanner import main

if __name__ == "__main__":
    bannerr()
    banner()
    main()

def banner():
    print('''
______  __             ________________________
___  / / ____  __________  /___  __ __  /___  /______  _________  |  Version: v1.3
__  /_/ /_  / / __  __ _  ____  /_/ _  ____  __ __  / / __  ___/  |  Developed by Eyup Sukru ERGIN
Developed by TRHACKNON
_  __  / / /_/ /_  / / / /_ _  _, _// /_ _  / / _  /_/ /_(__  )   |  --------------------------------------
/_/ /_/  \__,_/ /_/ /_/\__/ /_/ |_| \__/ /_/ /_/_\__, / /____/    |  https://ergin.dev
                                                /____/            |  https://github.com/tucommenceapousser/huntrthys

Specific Rhadamanthys Command and Control Server Detection Tool'''+ "\n")
